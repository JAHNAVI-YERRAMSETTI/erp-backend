import React from "react";

const CounsellingDiary = () => {
  return <div></div>;
};

export default CounsellingDiary;
